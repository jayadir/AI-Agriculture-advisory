from contextlib import asynccontextmanager
from fastapi import FastAPI
from app.db.mongodb import connect_to_mongo, close_mongo_connection, get_database

async def create_indexes():
    db = await get_database()
    await db["users"].create_index("phone_number", unique=True)
    await db["users"].create_index([("location", "2dsphere")])
    await db["alert_reports"].create_index([("location", "2dsphere")])
    print("Indexes created")
    
@asynccontextmanager
async def lifespan(app: FastAPI):
    await connect_to_mongo()
    await create_indexes()
    yield
    await close_mongo_connection()
    
app = FastAPI(title="Agri-Brain API", lifespan=lifespan)
@app.get("/")
def read_root():
    return {"message": "Welcome to Agri-Brain API"}