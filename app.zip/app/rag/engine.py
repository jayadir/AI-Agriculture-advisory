import random
from app.models.chat import Message

class RAGEngine:
    
    def  __init__(self):
        pass
    
    async def process(self, query: str) -> dict:
        """
        The main logic:
        1. Embed Query
        2. Search Local Vector DB
        3. If confidence low -> Search Web
        """
        print(f"Processing query: {query}")
        
        # Simulate logic
        confidence = random.random()
        
        if confidence > 0.4:
            return {
                "response": f"Based on local data: Use Neem oil for {query}.",
                "source": "local",
                "confidence": confidence
            }
        else:
            return {
                "response": f"Web search indicates recent outbreaks. Recommended action for {query} is...",
                "source": "web",
                "confidence": confidence
            }

rag_engine = RAGEngine()

async def get_rag_engine():
    return rag_engine